java -Xmx2048M -Xms32M -jar minecraft_server.1.6.2.jar nogui
